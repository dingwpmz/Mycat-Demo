package persistent.prestige.study.dubbox.pre;

public class DubboxProvider {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 提供者，

	}

}
